package gov.fnal.eag.healpix.test;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

import gov.fnal.eag.healpix.BitManipulation;
import gov.fnal.eag.healpix.PixTools;
import javax.vecmath.Vector3d;
import junit.framework.TestCase;

public class QueryDiscTest extends TestCase {
	public void testQueryDisc () {
	long nside = 32;
	
	int nest = 0;
	int inclusive = 0;
	double radius = Math.PI;
	double radius1 = Math.PI/2.;
    PixTools pt = new PixTools();
    int npix = (int) pt.Nside2Npix(nside);
    double res = pt.PixRes(nside); // pixel size in radians
    System.out.println("res="+res);
    double pixSize = Math.toRadians(res/3600.0); // pixel size in radians
    System.out.println("pixSize="+pixSize+" rad");

    
    ArrayList fullSky = pt.query_disc(nside, new Vector3d(0., 0., 1.), radius, nest, inclusive);
    ArrayList firstHalfSky = pt.query_disc(nside, new Vector3d(0., 0., 1.), radius1, nest, inclusive);
    ArrayList secondHalfSky = pt.query_disc(nside, new Vector3d(0., 0., -1.), radius1, nest, inclusive);
    firstHalfSky.addAll(secondHalfSky);
    HashSet pixHalfsUnique = new HashSet(firstHalfSky);
    ArrayList pixHalfsList = new ArrayList(pixHalfsUnique);
    Collections.sort(pixHalfsList);
    Collections.sort(fullSky);

    long listL = Math.min(fullSky.size(),pixHalfsList.size() );
    assertEquals(npix,fullSky.size());
    assertEquals(npix,listL);
    for ( int i=0; i< listL; i++) {

    assertEquals(fullSky.get(i),pixHalfsList.get(i));
    }
    
    double[] ang_tup = { 0., 0. };
    Vector3d v = new Vector3d(1., 0., 0.);
    Vector3d v1 = new Vector3d(-1., 0., 0.);
	ang_tup = pt.Vect2Ang(v);

   firstHalfSky = pt.query_disc(nside, new Vector3d(1., 0., 0.), radius1, nest, inclusive);
   secondHalfSky = pt.query_disc(nside, new Vector3d(-1., 0., 0.),radius1, nest, inclusive);
    firstHalfSky.addAll(secondHalfSky);
    pixHalfsUnique = new HashSet(firstHalfSky);
    pixHalfsList = new ArrayList(pixHalfsUnique);
    
    Collections.sort(pixHalfsList);
    System.out.println("full size="+fullSky.size()+" half size="+pixHalfsList.size());
    listL = Math.min(fullSky.size(),pixHalfsList.size() );
    assertEquals(npix,fullSky.size());
    assertEquals(npix,listL);
    for ( int i=0; i< listL; i++) {
//        System.out.println( "i="+i+" "+fullSky.get(i)+" "+pixHalfsList.get(i));
        assertEquals(fullSky.get(i),pixHalfsList.get(i));
        }


    firstHalfSky = pt.query_disc(nside, new Vector3d(0., 1., 0.), radius1, nest, inclusive);
    secondHalfSky = pt.query_disc(nside, new Vector3d(0., -1., 0.), radius1, nest, inclusive);
    firstHalfSky.addAll(secondHalfSky);
    pixHalfsUnique = new HashSet(firstHalfSky);
    pixHalfsList = new ArrayList(pixHalfsUnique);
    Collections.sort(pixHalfsList);
    System.out.println("full size="+fullSky.size()+" half size="+pixHalfsList.size());
    listL = Math.min(fullSky.size(),pixHalfsList.size() );
    assertEquals(npix,fullSky.size());

    for ( int i=0; i< listL; i++) {

        assertEquals(fullSky.get(i),pixHalfsList.get(i));
        }
        
}
}
