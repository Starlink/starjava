package uk.ac.starlink.hello;

import java.io.IOException;
import java.io.InputStream;

public class HelloWorld {

    private static final String PEOPLE_FILE = "uk/ac/starlink/hello/greet.txt";

    public static void main( String[] args ) throws IOException {
        InputStream strm = HelloWorld.class.getClassLoader()
                          .getResourceAsStream( PEOPLE_FILE );
        StringBuffer person = new StringBuffer();
        for ( int val; ( val = strm.read() ) != -1; ) {
            if ( (char) val == '\n' ) {
                System.out.println( "Hello " + person );
                person = new StringBuffer();
            }
            else {
                person.append( (char) val );
            }
        }
    }
}
