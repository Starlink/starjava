/*
 * $Id: GraphicsPane.java,v 1.7 1998/12/21 06:51:07 johnr Exp $
 *
 * Copyright (c) 1998 The Regents of the University of California.
 * All rights reserved.  See the file COPYRIGHT for details.
 *
 */
package diva.canvas;

import diva.canvas.event.EventLayer;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * A CanvasPane which has a default set of layers that are
 * useful for interactive drawing and editing applications.
 * The layers are organized as follows:
 *
 * <PRE>
 *   (front)  Foreground event
 *            Overlay
 *            Foreground graphics
 *            Background graphics
 *            Background event
 * </PRE>
 *
 * This organization allows applications to easily
 * overlay and underlay graphics and event handling
 * around the main application window. <p>
 *
 * Typical uses of each of these layers include:
 *
 * <dt>
 * <dt>Foreground event layer</dt>
 * <dd>Grid or object snapping, stroke filtering, 
 * event monitoring and debugging, event grab, etc.
 * By default, this layer is not enabled. If you
 * enable it, but still want events to go through to
 * the underlying figure layers, use setConsuming(false).
 *
 * <dt>Overlay</dt>
 * <dd>An overlay layer for drag-selection outlining and so
 * on. By default, this layer is an instance of OverlayLayer
 * and is set visible.
 *
 * <dt>Foreground graphics</dt>
 * <dd>The main application graphics. By default, this layer
 * is an instance of FigureLayer and is set enabled and visible.
 *
 * <dt>Background graphics
 * <dd>Auxiliary, non-interactive graphics. By default,
 * this layer is an instance of FigureLayer but is set
 * not visible and not enabled..
 *
 *  <dt>Background Event</dt>
 * <dd>"Last chance" event handling layer,
 * for things such as drag-selection rectangle, panning/zooming, etc.
 * By default, this layer is enabled.
 *
 * </dl>
 *
 * @author Michael Shilman  (michaels@eecs.berkeley.edu)
 * @author John Reekie      (johnr@eecs.berkeley.edu)
 * @version	$Revision: 1.7 $
*/
public class GraphicsPane extends CanvasPane {

    /*
     * The container of layers, makes it easier to
     * do iterators.
     */
    private ArrayList _layers = new ArrayList(6);

    /*
     * The indexes in to the layer list, to make it easier to set
     * layers.
     */
    private final static int BACKGROUND_EVENT_LAYER = 4;
    private final static int BACKGROUND_LAYER = 3;
    private final static int FOREGROUND_LAYER = 2;
    private final static int OVERLAY_LAYER = 1;
    private final static int FOREGROUND_EVENT_LAYER = 0;

     /*
      * The layers
      */
    private EventLayer _backgroundEventLayer;
    private CanvasLayer _backgroundLayer;
    private FigureLayer _foregroundLayer;
    private OverlayLayer _overlayLayer;
    private EventLayer _foregroundEventLayer;


    /** Create a new Graphics pane with an instance of
     * FigureLayer as the main figure layer.
     */
    public GraphicsPane() {
        this(new FigureLayer());
    }

    /** Create a new Graphics pane with the passed Layer
     * as the main graphics pane.
     */
    public GraphicsPane(FigureLayer foregroundLayer) {
        // Background events
        _backgroundEventLayer = new EventLayer();
        _backgroundEventLayer.setEnabled(true);

        // Background layer is a figure layer
        _backgroundLayer = new FigureLayer();
        ((FigureLayer)_backgroundLayer).setVisible(false);
        ((FigureLayer)_backgroundLayer).setEnabled(false);

        // Foreground figures
        _foregroundLayer = foregroundLayer;

        // Overlay layer
        _overlayLayer = new OverlayLayer();

        // Overlay events
        _foregroundEventLayer = new EventLayer();
        _foregroundEventLayer.setEnabled(false);

        // Initialize all these layers.
        _initNewLayer(_backgroundEventLayer);
        _initNewLayer(_backgroundLayer);
        _initNewLayer(_foregroundLayer);
        _initNewLayer(_overlayLayer);
        _initNewLayer(_foregroundEventLayer);

        // Add them to the layer array.
        _layers.add(_backgroundEventLayer);
        _layers.add(0,_backgroundLayer);
        _layers.add(0,_foregroundLayer);
        _layers.add(0,_overlayLayer);
        _layers.add(0,_foregroundEventLayer);
    }

    /** Get the background event layer
     */
    public EventLayer getBackgroundEventLayer() {
        return _backgroundEventLayer;
    }

    /** Get the background layer
     */
    public CanvasLayer getBackgroundLayer() {
        return _backgroundLayer;
    }

    /** Get the foreground layer
     */
    public FigureLayer getForegroundLayer() {
        return _foregroundLayer;
    }

    /** Get the overlay layer
     */
    public OverlayLayer getOverlayLayer() {
        return _overlayLayer;
    }

    /** Get the foreground event layer
     */
    public EventLayer getForegroundEventLayer() {
        return _foregroundEventLayer;
    }

    /** Return an iteration of the layers, in event-processing order
     * (that is, from front to back).
     */
    public Iterator layersFromFront () {
        return _layers.iterator();
    }

    /** Return an iteration of the layers, in redraw order (that is,
     * from back to front).
     */
    public Iterator layersFromBack () {
        return new Iterator() {
            int cursor = _layers.size();
            public boolean hasNext() {
                return cursor > 0;
            }
            public Object next() {
                cursor--;
                return _layers.get(cursor);
            }
            public void remove() {
                throw new UnsupportedOperationException(
                        "Cannot delete layer from canvas pane");
            }
        };
    }

    /** Set the background event layer
     */
    public void setBackgroundEventLayer (EventLayer l) {
      _nullifyLayer(_backgroundEventLayer);
      _backgroundEventLayer = l;
      _initNewLayer(l);
      _layers.set(BACKGROUND_EVENT_LAYER, l);
    }

    /** Set the background figure layer
     */
    public void setBackgroundLayer (CanvasLayer l) {
      _nullifyLayer(_backgroundLayer);
      _backgroundLayer = l;
      _initNewLayer(l);
      _layers.set(BACKGROUND_LAYER, l);
    }

    /** Set the foreground figure layer
     */
    public void setForegroundLayer (FigureLayer l) {
      _nullifyLayer(_foregroundLayer);
      _foregroundLayer = l;
      _initNewLayer(l);
      _layers.set(FOREGROUND_LAYER, l);
    }

    /** Set the overlay layer
     */
    public void setOverlayLayer (OverlayLayer l) {
      _nullifyLayer(_overlayLayer);
      _overlayLayer = l;
      _initNewLayer(l);
      _layers.set(OVERLAY_LAYER, l);
    }

    /** Set the foreground event layer
     */
    public void setForegroundEventLayer (EventLayer l) {
      _nullifyLayer(_foregroundEventLayer);
      _foregroundEventLayer = l;
      _initNewLayer(l);
      _layers.set(FOREGROUND_EVENT_LAYER, l);
    }
}
