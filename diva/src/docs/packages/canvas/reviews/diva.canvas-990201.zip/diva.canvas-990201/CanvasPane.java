/*
 * $Id: CanvasPane.java,v 1.30 1999/01/27 23:35:14 johnr Exp $
 *
 * Copyright (c) 1998 The Regents of the University of California.
 * All rights reserved.  See the file COPYRIGHT for details.
 *
 */

package diva.canvas;

import diva.canvas.event.LayerEvent;
import diva.canvas.event.EventAcceptor;

import java.awt.AWTEvent;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.RenderingHints;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;

/** A canvas pane groups canvas layers. The layers all share the same
 * logical-to-screen transform as the canvas pane. This is an abstract
 * superclass of all canvas panes, and provides the implementation of
 * everything related to panes but the storage of the
 * layers. Subclasses must provide methods to add and (possibly)
 * reorder and remove layers. Particular applications may choose
 * to create their own special-purpose sub-classes.
 * 
 * @version	$Revision: 1.30 $
 * @author John Reekie
*/
public abstract class CanvasPane implements EventAcceptor, CanvasComponent {

    /** The parent component.
     */
    private CanvasComponent _parent = null;

    /** The parent canvas.
     */
    private JCanvas _canvas = null;

    /** The enabled flag.
     */
    private boolean _enabled = true;

    /** The antialiasing flag
     */
    private boolean _antialias = true;
    
    /** The size of this pane, in logical coordinates
     */
    private Point2D _paneSize = new Point2D.Double(100.0,100.0);

    /** The transform context of this pane
     */
    private TransformContext _transformContext = new TransformContext(this);


    ///////////////////////////////////////////////////////////////////
    //// Public methods

    /** Dispatch an AWT event on this pane. Currently only
     * layer events are handled.
     */
    public void dispatchEvent (AWTEvent event) {
        if (event instanceof LayerEvent) {
            processLayerEvent((LayerEvent)event);
        } else {
            // FIXME
            System.out.println("Bad event: " + event);
        }
    }

    /** Get the parent component, or null if there isn't one.
     * Only one of the canvas or the display parent can be non-null.
     */
    public CanvasComponent getParent () {
        return _parent;
    }

    /** Get the containing canvas, or null if there isn't one.
     * Only one of the canvas or the display parent can be non-null.
     */
    public JCanvas getCanvas () {
        return _canvas;
    }

    /** Return whether or not this pane is antialiased
     */
    public boolean isAntialiasing () {
        return _antialias;
    }
    

    /** Return the transform context of this pane.
     */
    public TransformContext getTransformContext () {
        return _transformContext;
    }

    /** Get the size of this pane, in logical coordinates.
     * If the pane is contained directly in a JCanvas, the
     * size is obtained from the JCanvas. Otherwise, it
     * returns the size previously set with setSize().
     */
    public Point2D getSize () {
        if (_canvas != null) {
            Dimension d = _canvas.getSize();
            Point2D s = new Point2D.Double(d.width, d.height);
            _transformContext.getTransform().transform(s, s);
            return s;
        } else {
            return _paneSize;
        }
    }

    /** Test the enabled flag of this pane. Note that this flag
     *  does not indicate whether the pane is actually enabled,
     *  as its canvas or one if its ancestors may not be enabled.
     */
    public boolean isEnabled () {
        return _enabled;
    }
  
    /** Return an iteration of the layers, in undefined order. The
     * default implementation simply calls layersFromFront().
     */
    public Iterator layers () {
        return layersFromFront();
    }

    /** Return an iteration of the layers from back to front --
     * that is, in redraw order.
     */
    public abstract Iterator layersFromBack ();

    /** Return an iteration of the layers from front to back --
     * that is, in event-processing order.
     */
    public abstract Iterator layersFromFront ();

    /** Paint this pane onto a 2D graphics context. This implementation
     * paints all layers that implement VisibleComponent, from back
     * to front.  The transform of this pane is written
     * into the graphics context, so any layer that changes the
     * transform is obliged to return it to its prior state after
     * finishing.
     */
    public void paint (Graphics2D g) {
	_transformContext.push(g);

        if(isAntialiasing()) {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
        }

        CanvasLayer layer;
        Iterator i = layersFromBack();
        while (i.hasNext()) {
            layer = (CanvasLayer) i.next();
            if (layer instanceof VisibleComponent) {
                ((VisibleComponent) layer).paint(g);
            }
        }
	_transformContext.pop(g);
    }

    /** Paint this pane onto a 2D graphics object, within the given
     * region.  This implementation paints all layers that implement
     * VisibleComponent, from highest index to lowest index.  The
     * transform of this pane is written into the graphics context, so
     * any layer that changes the transform is obliged to return it to
     * its prior state after finishing.
     */
    public void paint (Graphics2D g, Rectangle2D region) {
        _transformContext.push(g);

        if(isAntialiasing()) {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
        }
        
        // Transform the region to paint as well
	AffineTransform t = _transformContext.getInverseTransform();
        if (!t.isIdentity()) {
	    if (CanvasUtilities.isOrthogonal(t)) {
                region = (Rectangle2D)CanvasUtilities.transform(region, t);
	    } else {
                region = t.createTransformedShape(region).getBounds2D();
            }
        }

        // paint the VisibleComponents
        CanvasLayer layer;
        Iterator i = layersFromBack();
        while (i.hasNext()) {
            layer = (CanvasLayer) i.next();
            if (layer instanceof VisibleComponent) {
                ((VisibleComponent) layer).paint(g, region);
            }
        }
	_transformContext.pop(g);
    }

    /** Process a layer event that has occurred on this pane.  If the
     * pane is not enabled, return without doing anything. Otherwise,
     * pass the event to each layer that implements the EventAcceptor
     * interface, from front to back. After each layer,
     * check whether the event has been consumed, and return if so.
     */
    protected void processLayerEvent (LayerEvent event) {
        if (!isEnabled()) {
            return;
        }
        Iterator i = layersFromFront();
        while (i.hasNext()) {
            CanvasLayer layer = (CanvasLayer) i.next();

            // Process on this layer only if it implements EventAccepter
            if (layer instanceof EventAcceptor) {
                EventAcceptor acceptor = (EventAcceptor) layer;

                // Set the layer source to the layer, then
		// pass the event to that layer
		event.setLayerSource(layer);
                acceptor.dispatchEvent(event);

                // stop if the event was consumed
		if (event.isConsumed()) {
                    break;
                }
            }
        }
    }
    
    /** Schedule a repaint of this pane. The pane passes
     * the repaint request to its parent, if it has one.
     */
    public void repaint () {
        if (_canvas != null) {
            _canvas.repaint();
        } else if (_parent != null) {
            _parent.repaint();
        }
    }

    /** Accept notification that a repaint has occurred somewhere
     * in this pane. Notify the damage region that it is passing
     * through a transform context, and then forward the
     * notification up to the parent.
     */
    public void repaint (DamageRegion d) {
        // Check the transform cache
        d.checkCacheValid(_transformContext);
        
        // Forward to parent
        if (_canvas != null) {
            _canvas.repaint(d);
        } else if (_parent != null) {
            _parent.repaint(d);
        }
    }
    
    /** Set whether or not to use antialiasing
     * when drawing this pane.
     */
    public void setAntialiasing(boolean val) {
        _antialias = val;
    }
    
    /** Set the containing canvas of this pane. If the canvas is
     * not null and the parent is not null, throw an exception.
     */
    public void setCanvas (JCanvas canvas) {
        if (canvas != null && _parent != null) {
            throw new IllegalArgumentException(
                    "Canvas pane cannot have a canvas as its parent is not null");
        }
        this._canvas = canvas;
    }
    
    /** Set the enabled flag of this pane. If the flag is false,
     * then the pane will not respond to user input events.
     */
    public void setEnabled (boolean flag) {
        _enabled = flag;
    }

    /** Set the parent component of this pane. If the parent is not
     * null and the canvas is not null, throw an exception.
     */
    public void setParent (CanvasComponent parent) {
        if (parent != null && _canvas != null) {
            throw new IllegalArgumentException(
                    "Canvas pane cannot have a parent as its canvas is not null");
        }
        if (_transformContext != null) {
            _transformContext.invalidateCache();
        }
        this._parent = parent;
    }
    
    /** Set the transform that maps logical coordinates into the
     * parent's coordinates. If there is no parent, the "parent" is
     * taken to be the screen. An exception will be thrown if
     * the transform is null. Note that the transform will
     * be remembered by this pane, so the caller must make sure
     * that it will not be subsequently modified.
     */
    public void setTransform (AffineTransform at) {
        _transformContext.setTransform(at);
        repaint();
    }

    /** Set the size of this pane, in logical coordinates. If the
     * pane is directly contained by a JCanvas, subsequent calls to
     * the getSize() and getPreferredSize() methods of the JCanvas
     * will return the size set here.
     */
    public void setSize (double width, double height) {
        _paneSize = new Point2D.Double(width, height);
    }

    /** Set the size of this pane, in logical coordinates. If the
     * pane is directly contained by a JCanvas, subsequent calls to
     * the getSize() and getPreferredSize() methods of the JCanvas
     * will return the size set here.
     */
    public void setSize (Point2D size) {
        _paneSize = size;
    }

    ///////////////////////////////////////////////////////////////////
    ////                       protected methods                   ////

    /** Helper method to initialize a layer when it is added to thos
     * pane. Any subclass must be sure to call this whenever it
     * creates a new layer or accepts one to add to itself.
     */
    protected void _initNewLayer(CanvasLayer l) {
        if (l._containingPane != null) {
            // FIXME
            throw new IllegalArgumentException("Invalid layer");
        }
        l._containingPane = this;
    }

    /** Helper method to tell a layer when it is been removed from
     * this pane. Any subclass must be sure to call this whenever it
     * removes a layer.
     */
    protected void _nullifyLayer(CanvasLayer l) {
        if (l._containingPane != this) {
            // FIXME
            throw new IllegalArgumentException("Invalid layer");
        }
        l._containingPane = null;
    }
}

