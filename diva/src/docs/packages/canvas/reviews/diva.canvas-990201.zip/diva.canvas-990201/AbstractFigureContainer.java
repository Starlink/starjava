/*
 * $Id: AbstractFigureContainer.java,v 1.15 1999/01/27 23:35:13 johnr Exp $
 *
 * Copyright (c) 1998 The Regents of the University of California.
 * All rights reserved.  See the file COPYRIGHT for details.
 *
 */

package diva.canvas;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;

import java.util.ArrayList;
import java.util.Iterator;

/** AbstractFigureContainer is an abstract class that roots the tree
 * of figure-containing classes.
 *
 * @version	$Revision: 1.15 $
 * @author 	John Reekie
 */
public abstract class AbstractFigureContainer extends AbstractFigure implements FigureContainer {
  
    /** Decorate a child figure, replacing the reference to the
     * child figure with the decorator.
     */
    public void decorate (Figure child, FigureDecorator decorator) {
        if (child.getParent() != this) {
            throw new IllegalArgumentException("Not a child");
        }
        child.repaint();
        decorator.setParent(this);
        decorator.setChild(child);
        swapChild(child, decorator);
        decorator.repaint();
    }

    /** Test if the given figure is a child of this composite.
     */
    public abstract boolean contains (Figure f);

    /** Return an iteration of the children, in an undefined order.
     */
    public abstract Iterator figures ();

    /** Return an iteration of the children, from
     * back to front. This is the order 
     * in which the children are painted.
     */
    public abstract Iterator figuresFromBack ();

    /** Return an iteration of the children, from
     * front to back. This is the order in which
     * events are intercepted.
     */
    public abstract Iterator figuresFromFront ();

    /** Return the number of child figures in this container.
     */
    public abstract int getFigureCount ();

    /** Paint this composite figure onto a 2D graphics object. If the layer
     * is not visible, return immediately. Otherwise paint all children
     * from back to front.
     */
    public void paint (Graphics2D g) {
        if (!isVisible()) {
            return;
        }
        Figure f;
        Iterator i = figuresFromBack();
        while (i.hasNext()) {
            f = (Figure) i.next();
            f.paint(g);
        }
    }

    /** Accept notification that a repaint has occurred somewhere
     * in the hierarchy below this container. This default implementation
     * simply forwards the notification to its parent.
     */
    public void repaint (DamageRegion d) {
        if (getParent() != null) {
            getParent().repaint(d);
        }
    }

    /** Given a rectangle, return the top-most descendent figure
     * that it hits. If none does, return null.
     */
    public Figure pick (Rectangle2D region) {
        return CanvasUtilities.pick(
                figuresFromFront(),
                region);
    }
    
    /** Replace the first figure, which must be a child, with the
     * second, which must not be a child.
     */
    protected abstract void swapChild (Figure child, Figure replacement);

    /** Transform this figure with the supplied transform.
     * This default implementation simply forwards the transform
     * call to each child.
     */
    public void transform (AffineTransform at) {
        repaint();
        Iterator i = figures();
        while (i.hasNext()) {
            Figure f = (Figure) i.next();
            f.transform(at);
        }
        repaint();
    }

    /** Translate this figure by the given distance.
     * This default implementation simply forwards the translate
     * call to each child.
     */
    public void translate (double x, double y) {
        repaint();
        Iterator i = figures();
        while (i.hasNext()) {
            Figure f = (Figure) i.next();
            f.translate(x,y);
        }
        repaint();
    }

    /** Remove a figure from the given decorator and add
     * it back into this container.
     */
    public void undecorate (FigureDecorator decorator) {
        if (decorator.getParent() != this) {
            throw new IllegalArgumentException("Not a child");
        }
        decorator.repaint();
        Figure child = decorator.getChild();
        swapChild(decorator,child);
        decorator.setChild(null);
        decorator.setParent(null);
        child.setParent(this); // This is needed
        repaint();
    }
}

