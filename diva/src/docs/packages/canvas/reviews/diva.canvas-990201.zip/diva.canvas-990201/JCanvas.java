/*
 * $Id: JCanvas.java,v 1.29 1999/01/27 23:35:15 johnr Exp $
 *
 * Copyright (c) 1998 The Regents of the University of California.
 * All rights reserved.  See the file COPYRIGHT for details.
 *
 */

package diva.canvas;

import diva.canvas.event.*;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.AWTEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;


/** The JCanvas class is the center-piece of this package.  The canvas
 * is composed of a canvas pane, which in turn is composed of one or
 * more layers. Each layer may contain arbitrary graphics, although
 * commonly at least one layer is an instance of a "figure layer"
 * class that contains figure objects. The main role of the JCanvas
 * class is to provide the physical screen space on which layers draw
 * themselves, and to interface to the Swing component hierarchy.
 *
 * <p>
 * This architecture allows a graphics developer to write code for a
 * pane and a set of layers, without being concerned about whether the
 * pane and its layers will be directly contained by a JCanvas or
 * within some other layer. For example, it will be possible for a
 * visualization component to be "embedded" in a larger component.
 *
 * @version	$Revision: 1.29 $
 * @author John Reekie
 */
public class JCanvas extends JComponent {

    /** The off-screen image.
     */
    private BufferedImage _offscreen = null;

    /* The contained canvas pane.
     */
    private CanvasPane _canvasPane = null;

    /* A flag to tell us whether to work around the
     * clearRect bug in beta4
     */
    private boolean _workaroundClearRectBug = _checkForClearRectBug();

    /** Create a new canvas that contains a single GraphicsPane. This
     * is the simplest way of using the JCanvas. Mouse events on the
     * canvas are enabled by default.
     */
    public JCanvas ( ) {
        super();
        setCanvasPane(new GraphicsPane());
	enableEvents(AWTEvent.MOUSE_EVENT_MASK
		     | AWTEvent.MOUSE_MOTION_EVENT_MASK );
    }

    /** Create a new canvas that contains the given CanvasPane. Mouse
     * events on the canvas are enabled by default.
     */
    public JCanvas (CanvasPane pane) {
        super();
        setCanvasPane(pane);
	enableEvents(AWTEvent.MOUSE_EVENT_MASK
		     | AWTEvent.MOUSE_MOTION_EVENT_MASK );
    }

    /** Get the canvas pane contained by this component.
     */
    public CanvasPane getCanvasPane () {
        return _canvasPane;
    }

    /** Paint the canvas. Every layer in this canvas will be
     * requested to paint itself.
     * <p>
     * This method allocates an offscreen buffer if necessary, and then
     * paints the canvas into the right buffer and blits it to the
     * on-screen buffer.
     * <p>
     * Acknowledgement: some of this code was adapted from code
     * posted by Jonathon Knudsen to the Java2D mailing list, May
     * 1998.
     */
    public void paint (Graphics g) {
        // It appears that Swing already sets the clip region when
        // we are ready to draw. So let's see if we are drawing the
        // whole canvas or not...
        Rectangle clip = g.getClipBounds();
        Dimension d = getSize();
        boolean paintAll = (clip.x == 0 && clip.y == 0
                && clip.width == d.width
                && clip.height == d.height);

        if (!isDoubleBuffered()) {
            Graphics2D g2d = (Graphics2D) g;

            // Clear it to white
            g2d.setBackground(Color.white);
            if (_workaroundClearRectBug) {
                g2d.clearRect(0, 0, clip.width, clip.height);
            } else {
                g2d.clearRect(clip.x, clip.y, clip.width, clip.height);
            }

            // Draw directly onto the graphics pane
            if (paintAll) {
                _canvasPane.paint(g2d);
            } else {
                _canvasPane.paint(g2d, clip);
            }
        } else {
            // Get a new offscreen buffer if necessary
            if (_offscreen == null ||
                    _offscreen.getWidth() != clip.width ||
                    _offscreen.getHeight() != clip.height) {
                _offscreen = null;    // in case GC needs it
                _offscreen = new BufferedImage(
                        clip.width,
                        clip.height,
                        BufferedImage.TYPE_INT_RGB);
            }
            Graphics2D g2d = _offscreen.createGraphics();

            // Clear it to white
            g2d.setBackground(Color.white);
            if (_workaroundClearRectBug) {
                g2d.clearRect(0, 0, clip.width, clip.height);
            } else {
                g2d.clearRect(clip.x, clip.y, clip.width, clip.height);
            }

            // Paint on it
            if (paintAll) {
                _canvasPane.paint(g2d);
            } else {
                // Translate drawing into the offscreen buffer
                g2d.translate(-clip.x,-clip.y);

                // Paint the root canvas pane in the clip region
                _canvasPane.paint(g2d, clip);
            }

            // Blit it to the onscreen buffer
            g.drawImage(_offscreen, clip.x, clip.y, null);
        }

	super.paint(g);
    }

    /** Accept notification that a repaint has occurred on
     * in this canvas. Call the given damage region to generate
     * the appopriate calls to the Swing repaint manager.
     */
    public void repaint (DamageRegion d) {
        d.apply(this);
    }

    /** Set the canvas pane contained by this JCanvas.
     * If there is already a pane in this JCanvas, replace it.
     * If the pane already is in a canvas, remove it from
     * that other canvas.
     */
    public void setCanvasPane (CanvasPane pane) {
        if (_canvasPane != null) {
	  _canvasPane.setCanvas(null);
        }
        _canvasPane = pane;
        if (pane != null) {
            pane.setCanvas(this);
        }
    }

    /** Turn double-buffering on this canvas on or off.
     * This method overrides the inherited method to
     * delete the off-screen buffer.
     */
    public void setDoubleBuffered (boolean flag) {
        super.setDoubleBuffered(flag);
        if (!isDoubleBuffered()) {
            _offscreen = null;
        }
    }

    /** Set the preferred size of this JCanvas. In addition to calling
     * the superclass method, this calls setSize() on the contained pane.
     */
    public void setPreferredSize (Dimension d) {
        super.setPreferredSize(d);

        if (_canvasPane != null) {
            // FIXME: Transform size!!!
            Dimension size = getSize();
            Point2D s = new Point2D.Double(size.width, size.height);
            _canvasPane.setSize(s);
        }
    }


    ///////////////////////////////////////////////////////////////////////
    //// protected methods

    /** Process a mouse event. This method overrides the inherited
     * method to create a LayerEvent or LayerMotionEvent and pass the
     * event on to its pane (if it is not null).  If, after being
     * passed to the pane, the event is still not consumed, then
     * the mouse event is passed to the superclass' method for
     * handling.
     */
    protected void processMouseEvent(MouseEvent e) {
        internalProcessMouseEvent(e);
	if ( !(e.isConsumed()) ) {
	  super.processMouseEvent(e);
	}
    }

    /** Process a mouse motion event. This method overrides the
     * inherited method to create a LayerEvent or LayerMotionEvent
     * and pass the event on to its pane (if it is not null).  If,
     * after being passed to the pane, the event is still not consumed,
     * then the mouse event is passed to the superclass' method for
     * handling.
     */
    protected void processMouseMotionEvent(MouseEvent e) {
        internalProcessMouseEvent(e);
	if ( !(e.isConsumed()) ) {
	  super.processMouseMotionEvent(e);
	}
     }

    ///////////////////////////////////////////////////////////////////////
    ////                      private methods                        ////

    /** Process a mouse event. This internal method is called
     * by both processMouseEvent() and processMouseMotionEvent().
     *
     * <p>FIXME: implement pointer grab here.
     */
    private void internalProcessMouseEvent(MouseEvent e) {
        LayerEvent layerevent = null;

        if (_canvasPane == null) {
            return;
        }

        // Create a new event and transform layer coordinates if necessary
        layerevent = new LayerEvent(e);
        AffineTransform at =
            _canvasPane.getTransformContext().getInverseTransform();
        if (!at.isIdentity()) {
            layerevent.transform(at);
        }

        // Process it on the pane
        _canvasPane.dispatchEvent(layerevent);
    }

    /** Check for  the clearRect bug by looking at the JDK version
     */
    private boolean _checkForClearRectBug() {
        return System.getProperty("java.version").equals("1.2beta4");
    }
}
