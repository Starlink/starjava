
Provides source code of java tools compatible with HEALPIX methods to work 
with sky pixelization.

AUTHOR:
            Nikolay Kuropatkin kuropat@fnal.gov
            
            
Java docs of all included classes are in doc subdirectory
                    
